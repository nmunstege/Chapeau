﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChapeauDAL
{
    class LogInDao
    {
        string user;
    }
}
