﻿using System;


namespace ChapeauModel
{
    public enum PaymentMethods
    {cash = 1, pin,debitCard,visa,credit,masterCard,americanExpress}
}
